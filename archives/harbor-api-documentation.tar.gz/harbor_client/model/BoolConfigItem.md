---
title: BoolConfigItem
description: 
date: 
draft: false
---

# BoolConfigItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **bool** | The boolean value of current config item | [optional] 
**editable** | **bool** | The configure item can be updated or not | [optional] 


