---
title: RetentionPolicy
description: 
date: 
draft: false
---

# RetentionPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**algorithm** | **str** |  | [optional] 
**rules** | [**list[RetentionRule]**](../retentionrule) |  | [optional] 
**trigger** | [**RetentionRuleTrigger**](../retentionruletrigger) |  | [optional] 
**scope** | [**RetentionPolicyScope**](../retentionpolicyscope) |  | [optional] 


