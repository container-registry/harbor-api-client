---
title: ProjectMember
description: 
date: 
draft: false
---

# ProjectMember

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_id** | **int** | The role id 1 for projectAdmin, 2 for developer, 3 for guest, 4 for maintainer | [optional] 
**member_user** | [**UserEntity**](../userentity) |  | [optional] 
**member_group** | [**UserGroup**](../usergroup) |  | [optional] 


