---
title: RetentionRule
description: 
date: 
draft: false
---

# RetentionRule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**priority** | **int** |  | [optional] 
**disabled** | **bool** |  | [optional] 
**action** | **str** |  | [optional] 
**template** | **str** |  | [optional] 
**params** | **dict(str, object)** |  | [optional] 
**tag_selectors** | [**list[RetentionSelector]**](../retentionselector) |  | [optional] 
**scope_selectors** | **dict(str, list[RetentionSelector])** |  | [optional] 


