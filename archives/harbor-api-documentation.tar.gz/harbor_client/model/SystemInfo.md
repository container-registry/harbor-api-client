---
title: SystemInfo
description: 
date: 
draft: false
---

# SystemInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storage** | [**list[Storage]**](../storage) | The storage of system. | [optional] 


