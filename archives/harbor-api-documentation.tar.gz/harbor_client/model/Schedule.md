---
title: Schedule
description: 
date: 
draft: false
---

# Schedule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The id of the schedule. | [optional] 
**status** | **str** | The status of the schedule. | [optional] 
**creation_time** | **datetime** | the creation time of the schedule. | [optional] 
**update_time** | **datetime** | the update time of the schedule. | [optional] 
**schedule** | [**ScheduleObj**](../scheduleobj) |  | [optional] 
**parameters** | **dict(str, object)** | The parameters of schedule job | [optional] 


