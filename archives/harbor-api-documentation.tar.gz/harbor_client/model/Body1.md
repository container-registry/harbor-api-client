---
title: Body1
description: 
date: 
draft: false
---

# Body1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | **str** |  | [optional] 


