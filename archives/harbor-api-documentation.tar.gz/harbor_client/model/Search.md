---
title: Search
description: 
date: 
draft: false
---

# Search

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project** | [**list[Project]**](../project) | Search results of the projects that matched the filter keywords. | [optional] 
**repository** | [**list[SearchRepository]**](../searchrepository) | Search results of the repositories that matched the filter keywords. | [optional] 
**chart** | [**list[SearchResult]**](../searchresult) | Search results of the charts that macthed the filter keywords. | [optional] 


