---
title: LdapUser
description: 
date: 
draft: false
---

# LdapUser

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** | ldap username. | [optional] 
**realname** | **str** | The user realname from \&quot;uid\&quot; or \&quot;cn\&quot; attribute. | [optional] 
**email** | **str** | The user email address from \&quot;mail\&quot; or \&quot;email\&quot; attribute. | [optional] 


