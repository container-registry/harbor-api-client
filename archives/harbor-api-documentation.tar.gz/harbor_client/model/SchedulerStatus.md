---
title: SchedulerStatus
description: 
date: 
draft: false
---

# SchedulerStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paused** | **bool** | if the scheduler is paused | [optional] 


