---
title: IsDefault
description: 
date: 
draft: false
---

# IsDefault

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_default** | **bool** | A flag indicating whether a scanner registration is default. | [optional] 


