---
title: RegistryEndpoint
description: 
date: 
draft: false
---

# RegistryEndpoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** | The endpoint key | [optional] 
**value** | **str** | The endpoint value | [optional] 


