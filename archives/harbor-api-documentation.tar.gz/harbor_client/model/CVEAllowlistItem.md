---
title: CVEAllowlistItem
description: 
date: 
draft: false
---

# CVEAllowlistItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cve_id** | **str** | The ID of the CVE, such as \&quot;CVE-2019-10164\&quot; | [optional] 


