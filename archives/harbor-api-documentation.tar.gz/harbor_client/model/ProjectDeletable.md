---
title: ProjectDeletable
description: 
date: 
draft: false
---

# ProjectDeletable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deletable** | **bool** | Whether the project can be deleted. | [optional] 
**message** | **str** | The detail message when the project can not be deleted. | [optional] 


