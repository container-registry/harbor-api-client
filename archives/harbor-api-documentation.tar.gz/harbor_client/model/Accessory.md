---
title: Accessory
description: 
date: 
draft: false
---

# Accessory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the accessory | [optional] 
**artifact_id** | **int** | The artifact id of the accessory | [optional] 
**subject_artifact_id** | **int** | The subject artifact id of the accessory | [optional] 
**size** | **int** | The artifact size of the accessory | [optional] 
**digest** | **str** | The artifact digest of the accessory | [optional] 
**type** | **str** | The artifact size of the accessory | [optional] 
**icon** | **str** | The icon of the accessory | [optional] 
**creation_time** | **datetime** | The creation time of the accessory | [optional] 


