---
title: RetentionSelectorMetadata
description: 
date: 
draft: false
---

# RetentionSelectorMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**display_text** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**decorations** | **list[str]** |  | [optional] 


