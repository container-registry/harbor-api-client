---
title: Error
description: 
date: 
draft: false
---

# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | The error code | [optional] 
**message** | **str** | The error message | [optional] 


