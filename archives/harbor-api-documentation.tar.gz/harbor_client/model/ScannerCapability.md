---
title: ScannerCapability
description: 
date: 
draft: false
---

# ScannerCapability

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**consumes_mime_types** | **list[str]** |  | [optional] 
**produces_mime_types** | **list[str]** |  | [optional] 


