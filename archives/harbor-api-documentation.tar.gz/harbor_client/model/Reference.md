---
title: Reference
description: 
date: 
draft: false
---

# Reference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**parent_id** | **int** | The parent ID of the reference | [optional] 
**child_id** | **int** | The child ID of the reference | [optional] 
**child_digest** | **str** | The digest of the child artifact | [optional] 
**platform** | [**Platform**](../platform) |  | [optional] 
**annotations** | [**Annotations**](../annotations) |  | [optional] 
**urls** | **list[str]** | The download URLs | [optional] 


