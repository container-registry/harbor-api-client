---
title: RegistryProviderEndpointPattern
description: 
date: 
draft: false
---

# RegistryProviderEndpointPattern

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpoint_type** | **str** | The endpoint type | [optional] 
**endpoints** | [**list[RegistryEndpoint]**](../registryendpoint) | The endpoint list | [optional] 


