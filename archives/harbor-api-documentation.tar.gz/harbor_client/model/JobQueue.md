---
title: JobQueue
description: 
date: 
draft: false
---

# JobQueue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_type** | **str** | The type of the job queue | [optional] 
**count** | **int** | The count of jobs in the job queue | [optional] 
**latency** | **int** | The latency the job queue (seconds) | [optional] 
**paused** | **bool** | The paused status of the job queue | [optional] 


