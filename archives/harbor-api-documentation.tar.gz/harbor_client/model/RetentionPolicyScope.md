---
title: RetentionPolicyScope
description: 
date: 
draft: false
---

# RetentionPolicyScope

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**level** | **str** |  | [optional] 
**ref** | **int** |  | [optional] 


