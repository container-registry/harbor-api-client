---
title: Icon
description: 
date: 
draft: false
---

# Icon

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**content_type** | **str** | The content type of the icon | [optional] 
**content** | **str** | The base64 encoded content of the icon | [optional] 


