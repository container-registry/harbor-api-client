---
title: ImmutableSelector
description: 
date: 
draft: false
---

# ImmutableSelector

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **str** |  | [optional] 
**decoration** | **str** |  | [optional] 
**pattern** | **str** |  | [optional] 
**extras** | **str** |  | [optional] 


