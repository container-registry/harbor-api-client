---
title: UserSysAdminFlag
description: 
date: 
draft: false
---

# UserSysAdminFlag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sysadmin_flag** | **bool** | true-admin, false-not admin. | [optional] 


