---
title: RetentionRuleTrigger
description: 
date: 
draft: false
---

# RetentionRuleTrigger

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **str** |  | [optional] 
**settings** | **object** |  | [optional] 
**references** | **object** |  | [optional] 


