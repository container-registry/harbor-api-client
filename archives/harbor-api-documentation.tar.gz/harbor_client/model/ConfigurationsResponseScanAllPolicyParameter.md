---
title: ConfigurationsResponseScanAllPolicyParameter
description: 
date: 
draft: false
---

# ConfigurationsResponseScanAllPolicyParameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**daily_time** | **int** | The offset in seconds of UTC 0 o&#39;clock, only valid when the policy type is \&quot;daily\&quot; | [optional] 


