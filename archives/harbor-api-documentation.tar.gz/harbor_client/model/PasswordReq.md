---
title: PasswordReq
description: 
date: 
draft: false
---

# PasswordReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**old_password** | **str** | The user&#39;s existing password. | [optional] 
**new_password** | **str** | New password for marking as to be updated. | [optional] 


