---
title: Quota
description: 
date: 
draft: false
---

# Quota

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | ID of the quota | [optional] 
**ref** | [**QuotaRefObject**](../quotarefobject) | The reference object of the quota | [optional] 
**hard** | [**ResourceList**](../resourcelist) | The hard limits of the quota | [optional] 
**used** | [**ResourceList**](../resourcelist) | The used status of the quota | [optional] 
**creation_time** | **datetime** | the creation time of the quota | [optional] 
**update_time** | **datetime** | the update time of the quota | [optional] 


