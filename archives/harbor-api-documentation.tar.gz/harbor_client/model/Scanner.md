---
title: Scanner
description: 
date: 
draft: false
---

# Scanner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of the scanner | [optional] 
**vendor** | **str** | Name of the scanner provider | [optional] 
**version** | **str** | Version of the scanner adapter | [optional] 


