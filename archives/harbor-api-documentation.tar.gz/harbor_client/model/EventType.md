---
title: EventType
description: 
date: 
draft: false
---

# EventType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


