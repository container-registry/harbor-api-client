---
title: RetentionSelector
description: 
date: 
draft: false
---

# RetentionSelector

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **str** |  | [optional] 
**decoration** | **str** |  | [optional] 
**pattern** | **str** |  | [optional] 
**extras** | **str** |  | [optional] 


