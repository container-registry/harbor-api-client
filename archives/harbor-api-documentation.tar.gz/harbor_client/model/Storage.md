---
title: Storage
description: 
date: 
draft: false
---

# Storage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **int** | Total volume size. | [optional] 
**free** | **int** | Free volume size. | [optional] 


