---
title: Errors
description: 
date: 
draft: false
---

# Errors

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errors** | [**list[Error]**](../error) |  | [optional] 


