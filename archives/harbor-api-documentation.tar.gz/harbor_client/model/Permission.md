---
title: Permission
description: 
date: 
draft: false
---

# Permission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource** | **str** | The permission resoruce | [optional] 
**action** | **str** | The permission action | [optional] 


