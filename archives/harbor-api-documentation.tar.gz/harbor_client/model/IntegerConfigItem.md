---
title: IntegerConfigItem
description: 
date: 
draft: false
---

# IntegerConfigItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **int** | The integer value of current config item | [optional] 
**editable** | **bool** | The configure item can be updated or not | [optional] 


