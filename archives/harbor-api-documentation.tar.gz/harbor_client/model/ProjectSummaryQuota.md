---
title: ProjectSummaryQuota
description: 
date: 
draft: false
---

# ProjectSummaryQuota

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hard** | [**ResourceList**](../resourcelist) | The hard limits of the quota | [optional] 
**used** | [**ResourceList**](../resourcelist) | The used status of the quota | [optional] 


