---
title: UserProfile
description: 
date: 
draft: false
---

# UserProfile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **str** |  | [optional] 
**realname** | **str** |  | [optional] 
**comment** | **str** |  | [optional] 


