---
title: OIDCCliSecretReq
description: 
date: 
draft: false
---

# OIDCCliSecretReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret** | **str** | The new secret | [optional] 


