---
title: ProjectReq
description: 
date: 
draft: false
---

# ProjectReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**project_name** | **str** | The name of the project. | [optional] 
**public** | **bool** | deprecated, reserved for project creation in replication | [optional] 
**metadata** | [**ProjectMetadata**](../projectmetadata) | The metadata of the project. | [optional] 
**cve_allowlist** | [**CVEAllowlist**](../cveallowlist) | The CVE allowlist of the project. | [optional] 
**storage_limit** | **int** | The storage quota of the project. | [optional] 
**registry_id** | **int** | The ID of referenced registry when creating the proxy cache project | [optional] 


