---
title: WebhookTargetObject
description: 
date: 
draft: false
---

# WebhookTargetObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The webhook target notify type. | [optional] 
**address** | **str** | The webhook target address. | [optional] 
**auth_header** | **str** | The webhook auth header. | [optional] 
**skip_cert_verify** | **bool** | Whether or not to skip cert verify. | [optional] 


