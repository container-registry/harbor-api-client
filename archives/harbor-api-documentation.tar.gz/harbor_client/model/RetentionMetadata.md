---
title: RetentionMetadata
description: 
date: 
draft: false
---

# RetentionMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**list[RetentionRuleMetadata]**](../retentionrulemetadata) | templates | [optional] 
**scope_selectors** | [**list[RetentionSelectorMetadata]**](../retentionselectormetadata) | supported scope selectors | [optional] 
**tag_selectors** | [**list[RetentionSelectorMetadata]**](../retentionselectormetadata) | supported tag selectors | [optional] 


