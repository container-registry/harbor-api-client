---
title: QuotaUpdateReq
description: 
date: 
draft: false
---

# QuotaUpdateReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hard** | [**ResourceList**](../resourcelist) | The new hard limits for the quota | [optional] 


