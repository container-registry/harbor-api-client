---
title: Endpoint
description: 
date: 
draft: false
---

# Endpoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | The URL of OIDC endpoint to be tested. | [optional] 
**verify_cert** | **bool** | Whether the certificate should be verified | [optional] 


