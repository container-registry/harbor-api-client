---
title: Access
description: 
date: 
draft: false
---

# Access

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource** | **str** | The resource of the access | [optional] 
**action** | **str** | The action of the access | [optional] 
**effect** | **str** | The effect of the access | [optional] 


