---
title: InternalConfigurationValue
description: 
date: 
draft: false
---

# InternalConfigurationValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **object** | The value of current config item | [optional] 
**editable** | **bool** | The configure item can be updated or not | [optional] 


