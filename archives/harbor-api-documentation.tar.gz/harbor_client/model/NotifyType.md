---
title: NotifyType
description: 
date: 
draft: false
---

# NotifyType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


