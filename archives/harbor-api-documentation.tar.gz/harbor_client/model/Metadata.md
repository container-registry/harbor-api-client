---
title: Metadata
description: 
date: 
draft: false
---

# Metadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | id | [optional] 
**name** | **str** | name | [optional] 
**icon** | **str** | icon | [optional] 
**maintainers** | **list[str]** | maintainers | [optional] 
**version** | **str** | version | [optional] 
**source** | **str** | source | [optional] 


