---
title: SupportedWebhookEventTypes
description: 
date: 
draft: false
---

# SupportedWebhookEventTypes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**event_type** | [**list[EventType]**](../eventtype) |  | [optional] 
**notify_type** | [**list[NotifyType]**](../notifytype) |  | [optional] 


