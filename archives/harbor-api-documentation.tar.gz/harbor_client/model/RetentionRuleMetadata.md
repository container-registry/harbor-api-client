---
title: RetentionRuleMetadata
description: 
date: 
draft: false
---

# RetentionRuleMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule_template** | **str** | rule id | [optional] 
**display_text** | **str** | rule display text | [optional] 
**action** | **str** | rule action | [optional] 
**params** | [**list[RetentionRuleParamMetadata]**](../retentionruleparammetadata) | rule params | [optional] 


