---
title: StringConfigItem
description: 
date: 
draft: false
---

# StringConfigItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | The string value of current config item | [optional] 
**editable** | **bool** | The configure item can be updated or not | [optional] 


