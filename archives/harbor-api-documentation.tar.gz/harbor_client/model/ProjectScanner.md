---
title: ProjectScanner
description: 
date: 
draft: false
---

# ProjectScanner

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**uuid** | **str** | The identifier of the scanner registration | 


