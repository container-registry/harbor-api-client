---
title: RegistryProviderInfo
description: 
date: 
draft: false
---

# RegistryProviderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpoint_pattern** | [**RegistryProviderEndpointPattern**](../registryproviderendpointpattern) | The endpoint pattern | [optional] 
**credential_pattern** | [**RegistryProviderCredentialPattern**](../registryprovidercredentialpattern) | The credential pattern | [optional] 


