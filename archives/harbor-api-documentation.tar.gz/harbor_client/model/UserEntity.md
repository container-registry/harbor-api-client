---
title: UserEntity
description: 
date: 
draft: false
---

# UserEntity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **int** | The ID of the user. | [optional] 
**username** | **str** | The name of the user. | [optional] 


