---
title: ScanDataExportExecutionList
description: 
date: 
draft: false
---

# ScanDataExportExecutionList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list[ScanDataExportExecution]**](../scandataexportexecution) | The list of scan data export executions | [optional] 


