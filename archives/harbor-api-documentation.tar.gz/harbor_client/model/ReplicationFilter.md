---
title: ReplicationFilter
description: 
date: 
draft: false
---

# ReplicationFilter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The replication policy filter type. | [optional] 
**value** | **object** | The value of replication policy filter. | [optional] 
**decoration** | **str** | matches or excludes the result | [optional] 


