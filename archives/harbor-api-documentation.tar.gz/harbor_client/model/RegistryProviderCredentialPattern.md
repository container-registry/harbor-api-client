---
title: RegistryProviderCredentialPattern
description: 
date: 
draft: false
---

# RegistryProviderCredentialPattern

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_key_type** | **str** | The access key type | [optional] 
**access_key_data** | **str** | The access key data | [optional] 
**access_secret_type** | **str** | The access secret type | [optional] 
**access_secret_data** | **str** | The access secret data | [optional] 


