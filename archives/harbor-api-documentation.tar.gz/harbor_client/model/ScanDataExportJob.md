---
title: ScanDataExportJob
description: 
date: 
draft: false
---

# ScanDataExportJob

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The id of the scan data export job | [optional] 


