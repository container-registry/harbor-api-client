---
title: UserSearch
description: 
date: 
draft: false
---

# UserSearch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **int** | The ID of the user. | [optional] 
**username** | **str** |  | [optional] 


