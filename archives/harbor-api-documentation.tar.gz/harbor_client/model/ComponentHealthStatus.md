---
title: ComponentHealthStatus
description: 
date: 
draft: false
---

# ComponentHealthStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The component name | [optional] 
**status** | **str** | The health status of component | [optional] 
**error** | **str** | (optional) The error message when the status is \&quot;unhealthy\&quot; | [optional] 


