---
title: LdapImportUsers
description: 
date: 
draft: false
---

# LdapImportUsers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ldap_uid_list** | **list[str]** | selected uid list | [optional] 


