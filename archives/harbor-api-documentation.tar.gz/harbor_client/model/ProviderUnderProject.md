---
title: ProviderUnderProject
description: 
date: 
draft: false
---

# ProviderUnderProject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**provider** | **str** |  | [optional] 
**enabled** | **bool** |  | [optional] 
**default** | **bool** |  | [optional] 


