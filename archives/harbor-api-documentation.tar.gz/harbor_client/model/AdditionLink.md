---
title: AdditionLink
description: 
date: 
draft: false
---

# AdditionLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**href** | **str** | The link of the addition | [optional] 
**absolute** | **bool** | Determine whether the link is an absolute URL or not | [optional] 


