---
title: ConfigurationsResponse
description: 
date: 
draft: false
---

# ConfigurationsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**auth_mode** | [**StringConfigItem**](../stringconfigitem) | The auth mode of current system, such as \&quot;db_auth\&quot;, \&quot;ldap_auth\&quot;, \&quot;oidc_auth\&quot; | [optional] 
**ldap_base_dn** | [**StringConfigItem**](../stringconfigitem) | The Base DN for LDAP binding. | [optional] 
**ldap_filter** | [**StringConfigItem**](../stringconfigitem) | The filter for LDAP search | [optional] 
**ldap_group_base_dn** | [**StringConfigItem**](../stringconfigitem) | The base DN to search LDAP group. | [optional] 
**ldap_group_admin_dn** | [**StringConfigItem**](../stringconfigitem) | Specify the ldap group which have the same privilege with Harbor admin | [optional] 
**ldap_group_attribute_name** | [**StringConfigItem**](../stringconfigitem) | The attribute which is used as identity of the LDAP group, default is cn.&#39; | [optional] 
**ldap_group_search_filter** | [**StringConfigItem**](../stringconfigitem) | The filter to search the ldap group | [optional] 
**ldap_group_search_scope** | [**IntegerConfigItem**](../integerconfigitem) | The scope to search ldap group. &#39;&#39;0-LDAP_SCOPE_BASE, 1-LDAP_SCOPE_ONELEVEL, 2-LDAP_SCOPE_SUBTREE&#39;&#39; | [optional] 
**ldap_scope** | [**IntegerConfigItem**](../integerconfigitem) | The scope to search ldap users,&#39;0-LDAP_SCOPE_BASE, 1-LDAP_SCOPE_ONELEVEL, 2-LDAP_SCOPE_SUBTREE&#39; | [optional] 
**ldap_search_dn** | [**StringConfigItem**](../stringconfigitem) | The DN of the user to do the search. | [optional] 
**ldap_timeout** | [**IntegerConfigItem**](../integerconfigitem) | Timeout in seconds for connection to LDAP server | [optional] 
**ldap_uid** | [**StringConfigItem**](../stringconfigitem) | The attribute which is used as identity for the LDAP binding, such as \&quot;CN\&quot; or \&quot;SAMAccountname\&quot; | [optional] 
**ldap_url** | [**StringConfigItem**](../stringconfigitem) | The URL of LDAP server | [optional] 
**ldap_verify_cert** | [**BoolConfigItem**](../boolconfigitem) | Whether verify your OIDC server certificate, disable it if your OIDC server is hosted via self-hosted certificate. | [optional] 
**ldap_group_membership_attribute** | [**StringConfigItem**](../stringconfigitem) | The user attribute to identify the group membership | [optional] 
**project_creation_restriction** | [**StringConfigItem**](../stringconfigitem) | Indicate who can create projects, it could be &#39;&#39;adminonly&#39;&#39; or &#39;&#39;everyone&#39;&#39;. | [optional] 
**read_only** | [**BoolConfigItem**](../boolconfigitem) | The flag to indicate whether Harbor is in readonly mode. | [optional] 
**self_registration** | [**BoolConfigItem**](../boolconfigitem) | Whether the Harbor instance supports self-registration.  If it&#39;&#39;s set to false, admin need to add user to the instance. | [optional] 
**token_expiration** | [**IntegerConfigItem**](../integerconfigitem) | The expiration time of the token for internal Registry, in minutes. | [optional] 
**uaa_client_id** | [**StringConfigItem**](../stringconfigitem) | The client id of UAA | [optional] 
**uaa_client_secret** | [**StringConfigItem**](../stringconfigitem) | The client secret of the UAA | [optional] 
**uaa_endpoint** | [**StringConfigItem**](../stringconfigitem) | The endpoint of the UAA | [optional] 
**uaa_verify_cert** | [**BoolConfigItem**](../boolconfigitem) | Verify the certificate in UAA server | [optional] 
**http_authproxy_endpoint** | [**StringConfigItem**](../stringconfigitem) | The endpoint of the HTTP auth | [optional] 
**http_authproxy_tokenreview_endpoint** | [**StringConfigItem**](../stringconfigitem) | The token review endpoint | [optional] 
**http_authproxy_admin_groups** | [**StringConfigItem**](../stringconfigitem) | The group which has the harbor admin privileges | [optional] 
**http_authproxy_admin_usernames** | [**StringConfigItem**](../stringconfigitem) | The usernames which has the harbor admin privileges | [optional] 
**http_authproxy_verify_cert** | [**BoolConfigItem**](../boolconfigitem) | Verify the HTTP auth provider&#39;s certificate | [optional] 
**http_authproxy_skip_search** | [**BoolConfigItem**](../boolconfigitem) | Search user before onboard | [optional] 
**http_authproxy_server_certificate** | [**StringConfigItem**](../stringconfigitem) | The certificate of the HTTP auth provider | [optional] 
**oidc_name** | [**StringConfigItem**](../stringconfigitem) | The OIDC provider name | [optional] 
**oidc_endpoint** | [**StringConfigItem**](../stringconfigitem) | The endpoint of the OIDC provider | [optional] 
**oidc_client_id** | [**StringConfigItem**](../stringconfigitem) | The client ID of the OIDC provider | [optional] 
**oidc_groups_claim** | [**StringConfigItem**](../stringconfigitem) | The attribute claims the group name | [optional] 
**oidc_admin_group** | [**StringConfigItem**](../stringconfigitem) | The OIDC group which has the harbor admin privileges | [optional] 
**oidc_group_filter** | [**StringConfigItem**](../stringconfigitem) | The OIDC group filter which filters out the group doesn&#39;t match the regular expression | [optional] 
**oidc_scope** | [**StringConfigItem**](../stringconfigitem) | The scope of the OIDC provider | [optional] 
**oidc_user_claim** | [**StringConfigItem**](../stringconfigitem) | The attribute claims the username | [optional] 
**oidc_verify_cert** | [**BoolConfigItem**](../boolconfigitem) | Verify the OIDC provider&#39;s certificate&#39; | [optional] 
**oidc_auto_onboard** | [**BoolConfigItem**](../boolconfigitem) | Auto onboard the OIDC user | [optional] 
**oidc_extra_redirect_parms** | [**StringConfigItem**](../stringconfigitem) | Extra parameters to add when redirect request to OIDC provider | [optional] 
**robot_token_duration** | [**IntegerConfigItem**](../integerconfigitem) | The robot account token duration in days | [optional] 
**robot_name_prefix** | [**StringConfigItem**](../stringconfigitem) | The rebot account name prefix | [optional] 
**notification_enable** | [**BoolConfigItem**](../boolconfigitem) | Enable notification | [optional] 
**quota_per_project_enable** | [**BoolConfigItem**](../boolconfigitem) | Enable quota per project | [optional] 
**storage_per_project** | [**IntegerConfigItem**](../integerconfigitem) | The storage quota per project | [optional] 
**audit_log_forward_endpoint** | [**StringConfigItem**](../stringconfigitem) | The endpoint of the audit log forwarder | [optional] 
**skip_audit_log_database** | [**BoolConfigItem**](../boolconfigitem) | Whether skip the audit log in database | [optional] 
**scan_all_policy** | [**ConfigurationsResponseScanAllPolicy**](../configurationsresponsescanallpolicy) |  | [optional] 
**session_timeout** | [**IntegerConfigItem**](../integerconfigitem) | The session timeout in minutes | [optional] 


