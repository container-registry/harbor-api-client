---
title: RobotCreated
description: 
date: 
draft: false
---

# RobotCreated

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | The ID of the robot | [optional] 
**name** | **str** | The name of the tag | [optional] 
**secret** | **str** | The secret of the robot | [optional] 
**creation_time** | **datetime** | The creation time of the robot. | [optional] 
**expires_at** | **int** | The expiration data of the robot | [optional] 


