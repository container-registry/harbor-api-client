---
title: RobotSec
description: 
date: 
draft: false
---

# RobotSec

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**secret** | **str** | The secret of the robot | [optional] 


