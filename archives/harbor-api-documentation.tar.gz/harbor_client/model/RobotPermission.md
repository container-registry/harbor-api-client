---
title: RobotPermission
description: 
date: 
draft: false
---

# RobotPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **str** | The kind of the permission | [optional] 
**namespace** | **str** | The namespace of the permission | [optional] 
**access** | [**list[Access]**](../access) |  | [optional] 


