# RegistryProviderEndpointPattern

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpoint_type** | **str** | The endpoint type | [optional] 
**endpoints** | [**list[RegistryEndpoint]**](RegistryEndpoint.md) | The endpoint list | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


