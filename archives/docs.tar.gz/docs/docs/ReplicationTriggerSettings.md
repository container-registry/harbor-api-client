# ReplicationTriggerSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cron** | **str** | The cron string for scheduled trigger | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


