# ScannerAdapterMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scanner** | [**Scanner**](Scanner.md) |  | [optional] 
**capabilities** | [**list[ScannerCapability]**](ScannerCapability.md) |  | [optional] 
**properties** | **dict(str, str)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


