# Access

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource** | **str** | The resource of the access | [optional] 
**action** | **str** | The action of the access | [optional] 
**effect** | **str** | The effect of the access | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


