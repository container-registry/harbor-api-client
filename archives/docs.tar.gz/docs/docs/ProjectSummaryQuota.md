# ProjectSummaryQuota

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hard** | [**ResourceList**](ResourceList.md) | The hard limits of the quota | [optional] 
**used** | [**ResourceList**](ResourceList.md) | The used status of the quota | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


