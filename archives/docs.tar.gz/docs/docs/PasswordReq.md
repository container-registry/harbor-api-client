# PasswordReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**old_password** | **str** | The user&#39;s existing password. | [optional] 
**new_password** | **str** | New password for marking as to be updated. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


