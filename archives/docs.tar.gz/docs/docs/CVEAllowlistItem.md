# CVEAllowlistItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cve_id** | **str** | The ID of the CVE, such as \&quot;CVE-2019-10164\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


