# QuotaUpdateReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hard** | [**ResourceList**](ResourceList.md) | The new hard limits for the quota | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


