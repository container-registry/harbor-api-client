# ReplicationTrigger

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The replication policy trigger type. The valid values are manual, event_based and scheduled. | [optional] 
**trigger_settings** | [**ReplicationTriggerSettings**](ReplicationTriggerSettings.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


