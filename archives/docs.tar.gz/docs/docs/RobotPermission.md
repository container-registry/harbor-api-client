# RobotPermission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **str** | The kind of the permission | [optional] 
**namespace** | **str** | The namespace of the permission | [optional] 
**access** | [**list[Access]**](Access.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


