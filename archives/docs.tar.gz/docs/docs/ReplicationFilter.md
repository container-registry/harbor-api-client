# ReplicationFilter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The replication policy filter type. | [optional] 
**value** | **object** | The value of replication policy filter. | [optional] 
**decoration** | **str** | matches or excludes the result | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


