# ProjectDeletable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**deletable** | **bool** | Whether the project can be deleted. | [optional] 
**message** | **str** | The detail message when the project can not be deleted. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


