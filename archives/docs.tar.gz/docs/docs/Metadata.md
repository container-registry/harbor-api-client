# Metadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | id | [optional] 
**name** | **str** | name | [optional] 
**icon** | **str** | icon | [optional] 
**maintainers** | **list[str]** | maintainers | [optional] 
**version** | **str** | version | [optional] 
**source** | **str** | source | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


