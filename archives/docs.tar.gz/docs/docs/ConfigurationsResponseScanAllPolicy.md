# ConfigurationsResponseScanAllPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The type of scan all policy, currently the valid values are \&quot;none\&quot; and \&quot;daily\&quot; | [optional] 
**parameter** | [**ConfigurationsResponseScanAllPolicyParameter**](ConfigurationsResponseScanAllPolicyParameter.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


