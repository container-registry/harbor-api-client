# FilterStyle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | The filter type | [optional] 
**style** | **str** | The filter style | [optional] 
**values** | **list[str]** | The filter values | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


