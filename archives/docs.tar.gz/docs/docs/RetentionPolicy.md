# RetentionPolicy

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** |  | [optional] 
**algorithm** | **str** |  | [optional] 
**rules** | [**list[RetentionRule]**](RetentionRule.md) |  | [optional] 
**trigger** | [**RetentionRuleTrigger**](RetentionRuleTrigger.md) |  | [optional] 
**scope** | [**RetentionPolicyScope**](RetentionPolicyScope.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


