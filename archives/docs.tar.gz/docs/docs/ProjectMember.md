# ProjectMember

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role_id** | **int** | The role id 1 for projectAdmin, 2 for developer, 3 for guest, 4 for maintainer | [optional] 
**member_user** | [**UserEntity**](UserEntity.md) |  | [optional] 
**member_group** | [**UserGroup**](UserGroup.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


