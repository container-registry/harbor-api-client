# UserSysAdminFlag

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sysadmin_flag** | **bool** | true-admin, false-not admin. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


