# ConfigurationsResponseScanAllPolicyParameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**daily_time** | **int** | The offset in seconds of UTC 0 o&#39;clock, only valid when the policy type is \&quot;daily\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


