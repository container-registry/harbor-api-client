# RegistryProviderInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endpoint_pattern** | [**RegistryProviderEndpointPattern**](RegistryProviderEndpointPattern.md) | The endpoint pattern | [optional] 
**credential_pattern** | [**RegistryProviderCredentialPattern**](RegistryProviderCredentialPattern.md) | The credential pattern | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


