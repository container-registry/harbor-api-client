# RetentionRuleMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule_template** | **str** | rule id | [optional] 
**display_text** | **str** | rule display text | [optional] 
**action** | **str** | rule action | [optional] 
**params** | [**list[RetentionRuleParamMetadata]**](RetentionRuleParamMetadata.md) | rule params | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


