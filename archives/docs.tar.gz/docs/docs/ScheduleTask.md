# ScheduleTask

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | the id of the Schedule task | [optional] 
**vendor_type** | **str** | the vendor type of the current schedule task | [optional] 
**vendor_id** | **int** | the vendor id of the current task | [optional] 
**cron** | **str** | the cron of the current schedule task | [optional] 
**update_time** | **datetime** | the update time of the schedule task | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


