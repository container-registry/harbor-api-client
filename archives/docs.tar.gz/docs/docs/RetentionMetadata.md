# RetentionMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**templates** | [**list[RetentionRuleMetadata]**](RetentionRuleMetadata.md) | templates | [optional] 
**scope_selectors** | [**list[RetentionSelectorMetadata]**](RetentionSelectorMetadata.md) | supported scope selectors | [optional] 
**tag_selectors** | [**list[RetentionSelectorMetadata]**](RetentionSelectorMetadata.md) | supported tag selectors | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


