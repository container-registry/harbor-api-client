# SystemInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**storage** | [**list[Storage]**](Storage.md) | The storage of system. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


